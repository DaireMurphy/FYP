#!/usr/bin/env python
# coding: utf-8

# In[18]:

from gensim.models import Word2Vec, KeyedVectors
import pandas as pd
import numpy as np
from flask import Flask, render_template,url_for, request
from forms import GenerateForm


# In[19]:


app = Flask(__name__)


# In[20]:




# In[21]:


@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')


# In[22]:
WikiModel = KeyedVectors.load_word2vec_format('wiki100k-w2v.cbow.bin', binary=True)
#GoogleModel = KeyedVectors.load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True)



@app.route("/recommend", methods= ['GET', 'POST'])
def recommend():
    if request.method == 'POST':
        indexes = request.form.getlist("check")
        myarray = np.asarray(indexes)
        keywordsX = []
        s_keywords = request.args.get("keywords", default = "")
        keyword = s_keywords.split(" ")
        result = WikiModel.most_similar(positive=keyword, topn=15)
        dfloop = pd.DataFrame(result, columns = ['Most Similar' , 'Vector Accuracy'])
        keywordsX = (dfloop['Most Similar'])
        for i in sorted(indexes, reverse=True):
             del keywordsX[i]
        return render_template("recommend.html", keywords=keywordsX, word=keyword)

    else:
        keywordsX = []
        s_keywords = request.args.get("keywords", default = "")
        keyword = s_keywords.split(' ')
        result = WikiModel.most_similar(positive=keyword, topn=15)
        dfloop = pd.DataFrame(result, columns = ['Most Similar' , 'Vector Accuracy'])
        keywordsX = (dfloop['Most Similar'])
        return render_template("recommend.html", keywords=keywordsX, word=keyword)


@app.route('/visualisations')
def visualisations():
     return render_template('visualisations.html')


# In[23]:


@app.route('/about')
def about():
     return render_template('about.html')


# In[ ]:
if __name__ == '__main__':
    app.run(debug=True)



